This data is collected from worldometer manually.
The columns are:
COU: country 3 character codes.
Total Population: number of citizens living on country land (persons).
Life Expectency Both: it is the number of years expected for a new child to live. It's taken for both males and females.
Urban Population %: Percentage of population living in cities.
Population Density: number of people living in 1 km^2 (kilometer square)
