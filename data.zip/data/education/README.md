This data is downloaded from https://worldpopulationreview.com/

direct links to data:
•Education by country 2020: countries/education-by-country/
•Education rankings by country: https://worldpopulationreview.com/countries/education-rankings-by-country/

